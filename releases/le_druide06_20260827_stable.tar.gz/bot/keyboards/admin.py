from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup


def admin_main_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="📦 Produits",
                    callback_data="admin_products",
                )
            ],
            [
                InlineKeyboardButton(
                    text="📂 Catégories",
                    callback_data="admin_categories",
                )
            ],
            [
                InlineKeyboardButton(
                    text="🛒 Commandes",
                    callback_data="admin_orders",
                )
            ],
            [
                InlineKeyboardButton(
                    text="💬 Support",
                    callback_data="admin_support",
                )
            ],
            [
                InlineKeyboardButton(
                    text="ℹ️ Informations",
                    callback_data="admin_information",
                )
            ],
            [
                InlineKeyboardButton(
                    text="🏷️ Promotions",
                    callback_data="admin_promotions",
                )
            ],
            [
                InlineKeyboardButton(
                    text="🔄 Actualiser",
                    callback_data="admin_home",
                )
            ],
            [
                InlineKeyboardButton(
                    text="🏠 Menu principal",
                    callback_data="back_to_menu",
                )
            ],
        ]
    )


def admin_orders_keyboard(orders):
    buttons = []

    status_labels = {
        "PENDING": "🟡",
        "PREPARING": "🔵",
        "READY": "🟢",
        "COMPLETED": "✅",
        "CANCELLED": "🔴",
    }

    for order in orders:
        icon = status_labels.get(order.status, "📦")

        buttons.append([
            InlineKeyboardButton(
                text=(
                    f"{icon} #{order.id} — "
                    f"{order.total:.2f} € — "
                    f"{order.status}"
                ),
                callback_data=f"admin_order:{order.id}",
            )
        ])

    buttons.append([
        InlineKeyboardButton(
            text="🔄 Actualiser",
            callback_data="admin_orders",
        )
    ])

    buttons.append([
        InlineKeyboardButton(
            text="⬅️ Administration",
            callback_data="admin_home",
        )
    ])

    return InlineKeyboardMarkup(
        inline_keyboard=buttons
    )


def admin_order_detail_keyboard(order):
    buttons = []

    if order.status == "PENDING":
        buttons.append([
            InlineKeyboardButton(
                text="🔵 PRÉPARER",
                callback_data=(
                    f"admin_status:{order.id}:PREPARING"
                ),
            )
        ])

        buttons.append([
            InlineKeyboardButton(
                text="❌ ANNULER",
                callback_data=(
                    f"admin_status:{order.id}:CANCELLED"
                ),
            )
        ])

    elif order.status == "PREPARING":
        buttons.append([
            InlineKeyboardButton(
                text="🟢 MARQUER PRÊTE",
                callback_data=(
                    f"admin_status:{order.id}:READY"
                ),
            )
        ])

        buttons.append([
            InlineKeyboardButton(
                text="❌ ANNULER",
                callback_data=(
                    f"admin_status:{order.id}:CANCELLED"
                ),
            )
        ])

    elif order.status == "READY":
        buttons.append([
            InlineKeyboardButton(
                text="✅ TERMINER LA COMMANDE",
                callback_data=(
                    f"admin_status:{order.id}:COMPLETED"
                ),
            )
        ])

    buttons.append([
        InlineKeyboardButton(
            text="⬅️ Commandes",
            callback_data="admin_orders",
        )
    ])

    buttons.append([
        InlineKeyboardButton(
            text="⬅️ Administration",
            callback_data="admin_home",
        )
    ])

    return InlineKeyboardMarkup(
        inline_keyboard=buttons
    )


def admin_category_list_keyboard(categories):
    buttons = []

    for category in categories:
        status = "🟢" if category.is_active else "🔴"

        buttons.append([
            InlineKeyboardButton(
                text=f"{status} #{category.id} {category.name}",
                callback_data=f"admin_category:{category.id}",
            )
        ])

    buttons.append([
        InlineKeyboardButton(
            text="➕ Ajouter une catégorie",
            callback_data="admin_category_add",
        )
    ])

    buttons.append([
        InlineKeyboardButton(
            text="🔄 Actualiser",
            callback_data="admin_categories",
        )
    ])

    buttons.append([
        InlineKeyboardButton(
            text="⬅️ Administration",
            callback_data="admin_home",
        )
    ])

    return InlineKeyboardMarkup(
        inline_keyboard=buttons
    )


def admin_category_detail_keyboard(category):
    buttons = []

    buttons.append([
        InlineKeyboardButton(
            text="✏️ Modifier",
            callback_data=f"admin_category_edit:{category.id}",
        )
    ])

    if category.is_active:
        buttons.append([
            InlineKeyboardButton(
                text="🔴 Désactiver",
                callback_data=f"admin_category_toggle:{category.id}",
            )
        ])
    else:
        buttons.append([
            InlineKeyboardButton(
                text="🟢 Activer",
                callback_data=f"admin_category_toggle:{category.id}",
            )
        ])

    buttons.append([
        InlineKeyboardButton(
            text="🗑️ Supprimer",
            callback_data=f"admin_category_delete:{category.id}",
        )
    ])

    buttons.append([
        InlineKeyboardButton(
            text="⬅️ Catégories",
            callback_data="admin_categories",
        )
    ])

    buttons.append([
        InlineKeyboardButton(
            text="⬅️ Administration",
            callback_data="admin_home",
        )
    ])

    return InlineKeyboardMarkup(
        inline_keyboard=buttons
    )
