from decimal import Decimal

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message
from sqlalchemy import delete, select

from bot.keyboards.cart import cart_keyboard, checkout_keyboard
from database.database import AsyncSessionLocal
from database.models import Cart, CartItem, Order, OrderItem, Product, User


router = Router()


async def get_or_create_cart(session, telegram_id: int):
    """
    Récupère le panier à partir de l'ID Telegram.

    Important :
    telegram_id = ID Telegram de l'utilisateur
    Cart.user_id = ID interne de la table users
    """

    user = await session.scalar(
        select(User).where(User.telegram_id == telegram_id)
    )

    if user is None:
        return None

    cart = await session.scalar(
        select(Cart).where(Cart.user_id == user.id)
    )

    if cart is None:
        cart = Cart(user_id=user.id)
        session.add(cart)
        await session.flush()

    return cart


async def get_cart_items(session, cart_id: int):
    result = await session.execute(
        select(
            CartItem.id,
            CartItem.quantity,
            Product.id.label("product_id"),
            Product.name,
            Product.price,
            Product.stock,
        )
        .join(Product, Product.id == CartItem.product_id)
        .where(CartItem.cart_id == cart_id)
        .order_by(CartItem.id)
    )

    return [dict(row._mapping) for row in result]


def calculate_total(items) -> Decimal:
    total = Decimal("0.00")

    for item in items:
        total += item["price"] * item["quantity"]

    return total


async def show_cart(callback: CallbackQuery):
    telegram_id = callback.from_user.id

    async with AsyncSessionLocal() as session:
        cart = await get_or_create_cart(session, telegram_id)

        if cart is None:
            await callback.answer(
                "Utilisateur non enregistré.",
                show_alert=True,
            )
            return

        await session.commit()

        items = await get_cart_items(session, cart.id)

    if not items:
        await callback.message.edit_text(
            """
🧺 MON PANIER

Votre panier est actuellement vide.

Rendez-vous dans 🛍️ Boutique pour ajouter des produits.
""",
            reply_markup=cart_keyboard([]),
        )
        return

    total = calculate_total(items)

    lines = [
        "🧺 <b>MON PANIER</b>",
        "",
    ]

    for item in items:
        subtotal = item["price"] * item["quantity"]

        lines.append(
            f"📦 <b>{item['name']}</b>\n"
            f"   {item['price']:.2f} € × {item['quantity']} = "
            f"<b>{subtotal:.2f} €</b>"
        )

    lines.extend(
        [
            "",
            f"💰 <b>Total : {total:.2f} €</b>",
            "",
            "💵 Paiement en liquide sur place.",
        ]
    )

    await callback.message.edit_text(
        "\n".join(lines),
        reply_markup=cart_keyboard(items),
    )


@router.callback_query(lambda callback: callback.data == "menu_cart")
async def cart_menu_handler(callback: CallbackQuery):
    await callback.answer()
    await show_cart(callback)


@router.callback_query(lambda callback: callback.data.startswith("add_cart:"))
async def add_to_cart_handler(callback: CallbackQuery):
    product_id = int(callback.data.split(":")[1])
    telegram_id = callback.from_user.id

    async with AsyncSessionLocal() as session:
        product = await session.scalar(
            select(Product).where(
                Product.id == product_id,
                Product.is_active.is_(True),
            )
        )

        if product is None:
            await callback.answer(
                "Produit introuvable.",
                show_alert=True,
            )
            return

        if product.stock <= 0:
            await callback.answer(
                "Produit en rupture de stock.",
                show_alert=True,
            )
            return

        cart = await get_or_create_cart(session, telegram_id)

        if cart is None:
            await callback.answer(
                "Veuillez utiliser /start puis accepter les conditions.",
                show_alert=True,
            )
            return

        cart_item = await session.scalar(
            select(CartItem).where(
                CartItem.cart_id == cart.id,
                CartItem.product_id == product.id,
            )
        )

        if cart_item is None:
            cart_item = CartItem(
                cart_id=cart.id,
                product_id=product.id,
                quantity=1,
            )
            session.add(cart_item)
        else:
            if cart_item.quantity >= product.stock:
                await callback.answer(
                    "Quantité maximale disponible atteinte.",
                    show_alert=True,
                )
                return

            cart_item.quantity += 1

        await session.commit()

    await callback.answer("✅ Produit ajouté au panier")


@router.callback_query(lambda callback: callback.data.startswith("cart_delete:"))
async def delete_cart_item_handler(callback: CallbackQuery):
    cart_item_id = int(callback.data.split(":")[1])
    telegram_id = callback.from_user.id

    async with AsyncSessionLocal() as session:
        cart = await get_or_create_cart(session, telegram_id)

        if cart is None:
            await callback.answer(
                "Panier introuvable.",
                show_alert=True,
            )
            return

        await session.execute(
            delete(CartItem).where(
                CartItem.id == cart_item_id,
                CartItem.cart_id == cart.id,
            )
        )

        await session.commit()

    await callback.answer("🗑️ Produit supprimé")
    await show_cart(callback)


@router.callback_query(lambda callback: callback.data.startswith("cart_item:"))
async def cart_item_handler(callback: CallbackQuery):
    await callback.answer()


@router.callback_query(lambda callback: callback.data.startswith("cart_increase:"))
async def increase_cart_item_handler(callback: CallbackQuery):
    cart_item_id = int(callback.data.split(":")[1])
    telegram_id = callback.from_user.id

    async with AsyncSessionLocal() as session:
        cart = await get_or_create_cart(
            session,
            telegram_id,
        )

        if cart is None:
            await callback.answer(
                "Panier introuvable.",
                show_alert=True,
            )
            return

        result = await session.execute(
            select(
                CartItem,
                Product,
            )
            .join(
                Product,
                Product.id == CartItem.product_id,
            )
            .where(
                CartItem.id == cart_item_id,
                CartItem.cart_id == cart.id,
            )
        )

        row = result.first()

        if row is None:
            await callback.answer(
                "Article introuvable.",
                show_alert=True,
            )
            return

        cart_item, product = row

        if not product.is_active:
            await callback.answer(
                "Ce produit n'est plus disponible.",
                show_alert=True,
            )
            return

        if cart_item.quantity >= product.stock:
            await callback.answer(
                "Quantité maximale disponible atteinte.",
                show_alert=True,
            )
            return

        cart_item.quantity += 1

        await session.commit()

    await callback.answer("➕ Quantité augmentée")
    await show_cart(callback)


@router.callback_query(lambda callback: callback.data.startswith("cart_decrease:"))
async def decrease_cart_item_handler(callback: CallbackQuery):
    cart_item_id = int(callback.data.split(":")[1])
    telegram_id = callback.from_user.id

    async with AsyncSessionLocal() as session:
        cart = await get_or_create_cart(
            session,
            telegram_id,
        )

        if cart is None:
            await callback.answer(
                "Panier introuvable.",
                show_alert=True,
            )
            return

        cart_item = await session.scalar(
            select(CartItem).where(
                CartItem.id == cart_item_id,
                CartItem.cart_id == cart.id,
            )
        )

        if cart_item is None:
            await callback.answer(
                "Article introuvable.",
                show_alert=True,
            )
            return

        if cart_item.quantity <= 1:
            await session.delete(cart_item)
            message = "🗑️ Produit retiré du panier"
        else:
            cart_item.quantity -= 1
            message = "➖ Quantité diminuée"

        await session.commit()

    await callback.answer(message)
    await show_cart(callback)


@router.callback_query(lambda callback: callback.data == "checkout")
async def checkout_handler(callback: CallbackQuery):
    telegram_id = callback.from_user.id

    async with AsyncSessionLocal() as session:
        cart = await get_or_create_cart(session, telegram_id)

        if cart is None:
            await callback.answer(
                "Utilisateur non enregistré.",
                show_alert=True,
            )
            return

        items = await get_cart_items(session, cart.id)

    if not items:
        await callback.answer(
            "Votre panier est vide.",
            show_alert=True,
        )
        return

    total = calculate_total(items)

    await callback.message.edit_text(
        f"""
🧾 VALIDATION DE LA COMMANDE

💰 Total : {total:.2f} €

💵 Paiement : liquide sur place

📍 Le retrait se fait directement sur place.

Confirmez-vous votre commande ?
""",
        reply_markup=checkout_keyboard(),
    )


@router.callback_query(lambda callback: callback.data == "cart_view")
async def cart_view_handler(callback: CallbackQuery):
    await callback.answer()
    await show_cart(callback)



@router.callback_query(lambda callback: callback.data == "confirm_order")
async def confirm_order_handler(callback: CallbackQuery):
    telegram_id = callback.from_user.id

    async with AsyncSessionLocal() as session:
        user = await session.scalar(
            select(User).where(
                User.telegram_id == telegram_id
            )
        )

        if user is None:
            await callback.answer(
                "Utilisateur non enregistré.",
                show_alert=True,
            )
            return

        cart = await get_or_create_cart(
            session,
            telegram_id,
        )

        if cart is None:
            await callback.answer(
                "Panier introuvable.",
                show_alert=True,
            )
            return

        items = await get_cart_items(
            session,
            cart.id,
        )

        if not items:
            await callback.answer(
                "Votre panier est vide.",
                show_alert=True,
            )
            return

        # Vérification complète du stock avant modification.
        for item in items:
            if item["stock"] < item["quantity"]:
                await callback.answer(
                    f"Stock insuffisant pour {item['name']}.",
                    show_alert=True,
                )
                return

        total = calculate_total(items)

        try:
            order = Order(
                user_id=user.id,
                status="PENDING",
                total=total,
                payment_method="CASH",
            )

            session.add(order)

            await session.flush()

            for item in items:
                quantity = item["quantity"]
                product_id = item["product_id"]

                order_item = OrderItem(
                    order_id=order.id,
                    product_id=product_id,
                    product_name=item["name"],
                    quantity=quantity,
                    unit_price=item["price"],
                    subtotal=item["price"] * quantity,
                )

                session.add(order_item)

                product = await session.scalar(
                    select(Product).where(
                        Product.id == product_id
                    ).with_for_update()
                )

                if product is None:
                    raise RuntimeError(
                        f"Produit introuvable : {product_id}"
                    )

                if product.stock < quantity:
                    raise RuntimeError(
                        f"Stock insuffisant : {product.name}"
                    )

                product.stock -= quantity

            await session.execute(
                delete(CartItem).where(
                    CartItem.cart_id == cart.id
                )
            )

            await session.commit()

        except Exception:
            await session.rollback()

            await callback.answer(
                "Impossible de confirmer la commande. "
                "Aucune modification n'a été effectuée.",
                show_alert=True,
            )
            return

    await callback.answer("✅ Commande enregistrée !")

    await callback.message.edit_text(
        f"""
✅ COMMANDE CONFIRMÉE

Votre commande #{order.id} a bien été enregistrée.

💰 Total : {total:.2f} €

💵 Paiement : liquide sur place
📦 Retrait : directement en boutique

Merci pour votre commande ! 🛍️
""",
    )



@router.message(Command("panier"))
async def panier_command_handler(message: Message):
    telegram_id = message.from_user.id

    async with AsyncSessionLocal() as session:
        cart = await get_or_create_cart(session, telegram_id)

        if cart is None:
            await message.answer(
                "Veuillez utiliser /start puis accepter les conditions."
            )
            return

        items = await get_cart_items(session, cart.id)

    if not items:
        await message.answer(
            """
🧺 MON PANIER

Votre panier est actuellement vide.

Rendez-vous dans 🛍️ Boutique pour ajouter des produits.
""",
            reply_markup=cart_keyboard([]),
        )
        return

    total = calculate_total(items)

    lines = [
        "🧺 <b>MON PANIER</b>",
        "",
    ]

    for item in items:
        subtotal = item["price"] * item["quantity"]

        lines.append(
            f"📦 <b>{item['name']}</b>\n"
            f"   {item['price']:.2f} € × {item['quantity']} = "
            f"<b>{subtotal:.2f} €</b>"
        )

    lines.extend(
        [
            "",
            f"💰 <b>Total : {total:.2f} €</b>",
            "",
            "💵 Paiement en liquide sur place.",
        ]
    )

    await message.answer(
        "\n".join(lines),
        reply_markup=cart_keyboard(items),
    )
